<div class="clearfix"></div>
         <footer class="site-footer">
            <div class="footer-inner bg-white">
               <div class="row">
                  <div class="col-sm-6">
                <center>  <h5><b>Made with <span style="font-size: 20px ;color: #00BFFF;" >&#10084;</span> by omkar gundre and team &copy;<?php echo date('Y')?></b></h5></center>
				  <p></p><h5><b><a href="mailto:sanjugundre3559@gmail.com">sanjugundre3559@gmail.com</a></b></h5>
				  <p></p><h5><b><a href="https://www.instagram.com/r_o_h_i_t_g_007?r=nametag" target="_blank"> INSTAGRAM</a></b></h5>
                  </div>                
               </div>
            </div>
         </footer>
</div>
      <script src="assets/js/vendor/jquery-2.1.4.min.js" type="text/javascript"></script>
      <script src="assets/js/popper.min.js" type="text/javascript"></script>
      <script src="assets/js/plugins.js" type="text/javascript"></script>
      <script src="assets/js/main.js" type="text/javascript"></script>
</body>
</html>
